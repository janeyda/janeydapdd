import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import { ServiciodenivelService } from 'src/app/serviciodenivel.service';

let contado = 0;
@Component({
  selector: 'app-casillas',
  templateUrl: './casillas.component.html',
  styleUrls: ['./casillas.component.sass']
  
})
export class CasillasComponent implements OnInit{
  @Input () lapalabra!: string
  @Input () lasletras!: any []
  @Input () habilitar!: number
 
  @Input () nivel: string = '';
 
 

  
  @Output () error = new EventEmitter<any>()
 
  
  filas: number[] = [];
  
  
  constructor(private servicionivel:ServiciodenivelService ) {}

  ngOnInit(): void {
   
    
    if (this.nivel === 'facil') {
      this.filas = [1, 2, 3, 4, 5, 6,7,8];
    } else if(this.nivel === 'medio'){
      this.filas=[1, 2, 3, 4, 5, 6]
    } else if (this.nivel === 'dificil') {
    this.filas = [1, 2, 3];

    } else {
    console.error('Valor  no manejado:');
    }
   
  }
 
  filasnivel(valor: number) {
    if (contado === 1) {
      this.filas = [1, 2, 3, 4, 5, 6,7,8];
    } else if(contado===2){
      this.filas=[1, 2, 3, 4, 5, 6]
    } else if (contado === 3) {
    this.filas = [1, 2, 3];

  } else {
    console.error('Valor de contado no manejado:', contado);
  }
    
   
   
  }
  
 erronio(e:any){
 
    console.log("Celda le dio una letra", e)  
  }

}

  

