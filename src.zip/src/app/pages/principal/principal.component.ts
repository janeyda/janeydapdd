import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { ServiciopalabrasService } from 'src/app/services/serviciopalabras.service';
import { ServiciodenivelService } from 'src/app/serviciodenivel.service';
let contado = 0;
@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.sass']
})
export class PrincipalComponent implements OnInit {
  
  constructor(
    private enrutar: Router
  ) {}

  ngOnInit(): void {
       
  }

  nivel(level: string){
    this.enrutar.navigate(['/tablero', level])
  }
}
